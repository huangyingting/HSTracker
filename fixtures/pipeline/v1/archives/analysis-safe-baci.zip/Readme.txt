BACI fixture
Version: TEST001
Release Date: 2026 01 22
