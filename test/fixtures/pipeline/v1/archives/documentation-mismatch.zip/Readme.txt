BACI fixture
Version: WRONG
Release Date: 2026 01 22
